#ifndef TIM3_H
#define TIM3_H
#include "stm32f10x.h"

void TIM3_Config(u8 freq,int Status);
void TIM3_T(void);


#endif

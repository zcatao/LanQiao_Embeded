#include "led.h"

#include "stm32f10x_gpio.h"



void LED_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = 0xff00;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = 0x04;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}


void LED_Control( u8 Status )
{
	if( Status )
		GPIO_ResetBits( GPIOC, 0x0100 );
	else
		GPIO_SetBits( GPIOC, 0x0100 );
		GPIO_SetBits( GPIOC, 0xfe00 );
		GPIO_SetBits( GPIOD, 0x04 );
		GPIO_ResetBits( GPIOD, 0x04 );
}



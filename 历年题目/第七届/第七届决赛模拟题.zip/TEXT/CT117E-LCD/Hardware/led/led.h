#ifndef LED_H
#define LED_H

#include "stm32f10x.h"

void LED_Config(void);
void LED_Control(u8 Status);



#endif

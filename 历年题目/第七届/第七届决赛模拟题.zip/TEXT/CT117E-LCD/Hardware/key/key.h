#ifndef KEY_H
#define KEY_H

#include "stm32f10x.h"

void KEY_Config(void);
int KEY_Scan(void);

#endif

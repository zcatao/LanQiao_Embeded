#include "key.h"
#include "stm32f10x_gpio.h"
#include "lcd.h"
#include "stdio.h"



void KEY_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
}


int KEY_Scan(void)
{
	if( (GPIOA->IDR & 0x01) == 0 )
	{
		while((GPIOA->IDR & 0x01) == 0);
		return 1;
	}
	
	if( (GPIOA->IDR & 0x100) == 0 )
	{
		while((GPIOA->IDR & 0x100) == 0);
		return 2;
	}
	
	if( (GPIOB->IDR & 0x02) == 0 )
	{
		while((GPIOB->IDR & 0x02) == 0);
		return 3;
	}
	
	if( (GPIOB->IDR & 0x04) == 0 )
	{
		while((GPIOB->IDR & 0x04) == 0);
		return 4;
	}
	
	return 0;
}

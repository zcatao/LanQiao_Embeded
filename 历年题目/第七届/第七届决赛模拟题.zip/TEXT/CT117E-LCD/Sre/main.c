#include "stm32f10x.h"
#include "lcd.h"
#include "adc.h"
#include "tim3.h"
#include "key.h"
#include "stdio.h"
#include "i2c.h"
#include "led.h"


u32 TimingDelay = 0;

int FLAG_ADC = 0;
int FLAG_KEY = 0;
int Freq = 1;
int Status = 0;
void Delay_Ms(u32 nTime);

//Main Body
int main(void)
{
	int flag = 0;
	int x = 0;
	u8 string[20];
	
	SysTick_Config(SystemCoreClock/1000);
	
	ADC_Config();
	KEY_Config();
	i2c_init();
	LED_Config();
	STM3210B_LCD_Init();
	LCD_Clear(Blue);
	LCD_SetBackColor(Blue);
	LCD_SetTextColor(White);
	
	Freq =  X24c02_Read(0x00);
	while(1)
	{
		
		if( FLAG_KEY )		
		{
			FLAG_KEY = 0;
			switch( KEY_Scan() )
			{
				case 0:
					if( !flag )
						if( FLAG_ADC )
						{
							FLAG_ADC = 0;
							ADC_T();
							TIM3_T();
							LED_Control(Status);
						}
					if( flag )
					{
						LCD_DisplayStringLine(Line2,"     Setting       ");
						if( x == 0 )
						{
							sprintf( (char*)string,"  Frequence:%dKHZ", Freq );
							LCD_DisplayStringLine(Line6,string);
						}
						if( x > 0 )
						{
							x = 0;
							LCD_ClearLine(Line6);
							sprintf( (char*)string,"  Frequence:%dKHZ", Freq );
							LCD_DisplayStringLine(Line6,string);
						}
					}
					
				break;
				
				case 1:
					Status = ~Status;
					LCD_ClearLine(Line4);
				break;
				
				case 2:
					flag = ~flag;
					LCD_Clear(Blue);
					X24c02_Write(0x00,Freq);
				break;
				
				case 3:
					if( flag )	
					{
						x++;
						if( ++Freq >= 10 ) Freq = 10;
					}
				break;
					
				case 4:
					if( flag )	
					{
						x++;
						if( --Freq <= 1 )	Freq = 1;
					}
				break;
			}
		}
	}
}

//
void Delay_Ms(u32 nTime)
{
	TimingDelay = nTime;
	while(TimingDelay != 0);	
}
